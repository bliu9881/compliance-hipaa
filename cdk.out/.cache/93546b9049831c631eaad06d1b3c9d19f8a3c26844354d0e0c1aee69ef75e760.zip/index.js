const githubProxy = require('./github-proxy');
exports.handler = githubProxy.handler;
